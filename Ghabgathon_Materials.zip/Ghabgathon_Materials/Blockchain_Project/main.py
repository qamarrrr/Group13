import json
from blockchain import Blockchain

def display_block_information(blockchain):
    for idx, block in enumerate(blockchain.chain):
        block_info = {
            "Index": idx,
            "Hash": block.hashid,
            "Timestamp": str(block.timestamp),  # Convert datetime to string
            "Block Information": block.transactions
        }
        print(json.dumps(block_info, indent=4))

def main():
    the_blockchain = Blockchain(20)

    # Read the JSON file and add transactions to the blockchain
    with open('THV_samples.json', 'r') as file:
        data = json.load(file)

    # Loop through transactions in the JSON file and add each to the blockchain
    for transaction in data:
        the_blockchain.add_to_transactions(transaction)
        mined_block = the_blockchain.mine_transactions()
        if isinstance(mined_block, str):
            print("Failed to mine block")

    # Display block information for each block in the blockchain
    display_block_information(the_blockchain)

if __name__ == "__main__":
    main()
